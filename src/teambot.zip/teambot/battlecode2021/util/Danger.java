package teambot.battlecode2021.util;

public class Danger {
    
}
