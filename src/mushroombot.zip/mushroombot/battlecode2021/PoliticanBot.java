package mushroombot.battlecode2021;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;
import mushroombot.RunnableBot;

public class PoliticanBot implements RunnableBot {
    private RobotController controller;
    public PoliticanBot(RobotController controller) {
        this.controller = controller;
    }

    @Override
    public void init() throws GameActionException {

    }

    @Override
    public void turn() throws GameActionException {

    }
}
