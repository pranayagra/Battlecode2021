package mushroombot.battlecode2021.util;

public class Danger {
    
}
