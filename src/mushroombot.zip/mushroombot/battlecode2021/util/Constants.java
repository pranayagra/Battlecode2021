package mushroombot.battlecode2021.util;
import battlecode.common.*;

public class Constants {

}
