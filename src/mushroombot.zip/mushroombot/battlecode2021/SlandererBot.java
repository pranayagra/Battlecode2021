package mushroombot.battlecode2021;

import battlecode.common.*;
import mushroombot.*;
import mushroombot.battlecode2021.util.Pathfinding;

public class SlandererBot implements RunnableBot {
    private RobotController controller;
    private Pathfinding pathfinding;
    public SlandererBot(RobotController controller) throws GameActionException {
        this.controller = controller;
    }

    @Override
    public void init() throws GameActionException {

    }

    @Override
    public void turn() throws GameActionException {
        
    }
}
